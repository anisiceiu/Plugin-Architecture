﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.Loader;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OAuth;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Mvc.ApplicationParts;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Framework.Module;
using Framework;

namespace MVCWebAPI.Extensions
{
    public static class ServiceCollectionExtensions
    {
        private static readonly ModuleConfigurationManager _moduleConfigurationManager = new ModuleConfigurationManager();
        public static IServiceCollection AddCustomizedServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddMemoryCache();
            var sp = services.BuildServiceProvider();
            var moduleInitializers = sp.GetServices<IModuleInitializer>();
            foreach (var moduleInitializer in moduleInitializers)
            {
                moduleInitializer.ConfigureServices(services);
            }
            ServiceContext.RegisterServices(services);
            return services;
        }

        public static IServiceCollection AddCustomizedAuthorization(this IServiceCollection services, IWebHostEnvironment webHostEnvironment)
        {
            
            return services;
        }

        public static IServiceCollection AddModules(this IServiceCollection services, string contentRootPath)
        {
            try
            {
                GlobalConfiguration.Modules = _moduleConfigurationManager.GetModules();
                ModuleAssemblyLoadContext context = new ModuleAssemblyLoadContext();
                foreach (var module in GlobalConfiguration.Modules)
                {
                    var dllFilePath = Path.Combine(contentRootPath, $@"Modules/{module.Id}/{module.Id}.dll");
                    var moduleFolder = new DirectoryInfo(dllFilePath);
                    if (File.Exists(moduleFolder.FullName))
                    {
                        using FileStream fs = new FileStream(moduleFolder.FullName, FileMode.Open);
                        module.Assembly = context.LoadFromStream(fs);
                        RegisterModuleInitializerServices(module, ref services);
                    }
                    else
                    {
                       throw new Exception($"{dllFilePath} file is not find!");
                    }
     
                    var viewsFilePath = Path.Combine(contentRootPath, $@"Modules/{module.Id}/{module.Id}.Views.dll");
                    moduleFolder = new DirectoryInfo(viewsFilePath);
                    if (File.Exists(moduleFolder.FullName))
                    {
                        using FileStream viewsFileStream = new FileStream(moduleFolder.FullName, FileMode.Open);
                        module.ViewsAssembly = context.LoadFromStream(viewsFileStream);
                    }
                    else
                    {
                        throw new Exception($"{viewsFilePath} file is not find!");
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return services;
        }

        public static IServiceCollection AddCustomizedMvc(this IServiceCollection services)
        {
            services.AddSession();

            var mvcBuilder = services.AddControllersWithViews(options=> {
            }).AddJsonOptions(options=> {
                });    
            foreach (var module in GlobalConfiguration.Modules)
            {
                if (module.IsApplicationPart)
                {
                    if (module.Assembly != null)
                        AddApplicationPart(mvcBuilder, module.Assembly);
                    if (module.ViewsAssembly != null)
                        mvcBuilder.PartManager.ApplicationParts.Add(new CompiledRazorAssemblyPart(module.ViewsAssembly));
                }
            }
            return services;
        }
        private static void AddApplicationPart(IMvcBuilder mvcBuilder, Assembly assembly)
        {
            var partFactory = ApplicationPartFactory.GetApplicationPartFactory(assembly);
            foreach (var part in partFactory.GetApplicationParts(assembly))
            {
                mvcBuilder.PartManager.ApplicationParts.Add(part);
            }
            
            var relatedAssemblies = RelatedAssemblyAttribute.GetRelatedAssemblies(assembly, throwOnError: false);
            foreach (var relatedAssembly in relatedAssemblies)
            {
                partFactory = ApplicationPartFactory.GetApplicationPartFactory(relatedAssembly);
                foreach (var part in partFactory.GetApplicationParts(relatedAssembly))
                {
                    mvcBuilder.PartManager.ApplicationParts.Add(part);
                    mvcBuilder.PartManager.ApplicationParts.Add(new CompiledRazorAssemblyPart(relatedAssembly));
                }
            }
        }
        private static void RegisterModuleInitializerServices(ModuleInfo module, ref IServiceCollection services)
        {
            if (module.Assembly != null)
            {
                var moduleInitializerType = module.Assembly.GetTypes()
                        .FirstOrDefault(t => typeof(IModuleInitializer).IsAssignableFrom(t));
                if ((moduleInitializerType != null) && (moduleInitializerType != typeof(IModuleInitializer)))
                {
                    services.AddSingleton(typeof(IModuleInitializer), moduleInitializerType);
                }
            }
        }
    }
}
