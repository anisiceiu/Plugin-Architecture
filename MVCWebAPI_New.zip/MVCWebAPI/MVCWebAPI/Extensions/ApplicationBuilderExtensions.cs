﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Hosting;

using System.IO;
using Microsoft.Extensions.FileProviders;
using Microsoft.AspNetCore.Http;
using Framework.Module;
using Framework;

namespace MVCWebAPI.Extensions
{
    public static class ApplicationBuilderExtensions
    {
        public static IApplicationBuilder UseCustomizedModuleConfigure(this IApplicationBuilder app,IWebHostEnvironment env)
        {
            var moduleInitializers = app.ApplicationServices.GetServices<IModuleInitializer>();
            foreach (var moduleInitializer in moduleInitializers)
            {
                moduleInitializer.Configure(app, env);
            }
            return app;
        }
        public static IApplicationBuilder UseCustomizedMiddleware(this IApplicationBuilder app)
        {
            return app;
        }
        public static IApplicationBuilder UseCustomizedMvc(this IApplicationBuilder app, IWebHostEnvironment env)
        {
            foreach (var module in GlobalConfiguration.Modules)
            {
                if (module.IsApplicationPart)
                {
                    var modulePath = $"{env.ContentRootPath}/Modules/{module.Id}/wwwroot";
                    if (Directory.Exists(modulePath))
                    {
                        app.UseStaticFiles(new StaticFileOptions()
                        {
                            FileProvider = new PhysicalFileProvider(modulePath),
                            RequestPath = new PathString($"/{module.Name}")
                        });
                    }
                }
            }
            //
            app.UseSession();
            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                foreach (var module in GlobalConfiguration.Modules)
                {
                    if (module.IsApplicationPart)
                    {
                        endpoints.MapAreaControllerRoute(
                            name: "area",
                           areaName: module.Name,
                           pattern: "{area:exists}/{controller}/{action=Index}/{id?}"
                         );
                    }
                }
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
            return app;
        }
    }
}
