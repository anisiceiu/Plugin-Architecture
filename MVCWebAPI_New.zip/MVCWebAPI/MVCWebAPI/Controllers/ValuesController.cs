﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        [HttpGet("TestError")]
        public IEnumerable<string> TestError()
        {
            throw new Exception("A sample test error from web api!");
            return new string[] { "value1", "value2" };
        }
    }
}
