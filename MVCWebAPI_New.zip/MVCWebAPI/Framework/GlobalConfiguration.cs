﻿using System;
using System.Collections.Generic;
using System.Text;
using Framework.Module;
namespace Framework
{
    public static class GlobalConfiguration
    {
        public static IList<ModuleInfo> Modules { get; set; } = new List<ModuleInfo>();
        public static string ContentRootPath { get; set; }
    }
}
