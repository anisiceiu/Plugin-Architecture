﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
namespace Framework
{
    public class ServiceContext
    {
        private static IServiceProvider _serviceProvider = null;
        public static void RegisterServices(IServiceCollection serviceCollection)
        {
            _serviceProvider = serviceCollection.BuildServiceProvider();
        }
        public static T GetService<T>()
        {
            if (_serviceProvider != null)
            {
                return _serviceProvider.GetService<T>();
            }
            return default(T);
        }
    }
}
