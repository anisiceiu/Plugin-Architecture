﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.


window.addEventListener("load", function () {
    var h1tag = document.querySelector('#dynamicText');
    if (h1tag) {
        h1tag.innerText = "This text has been replaced by JS.";
    }
});